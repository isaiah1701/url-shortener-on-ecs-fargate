const { ECSClient, DescribeTaskDefinitionCommand, RegisterTaskDefinitionCommand } = require("@aws-sdk/client-ecs");
const { CodeDeployClient, CreateDeploymentCommand } = require("@aws-sdk/client-codedeploy");

const REGION = process.env.AWS_REGION || "eu-west-2";
const ecs = new ECSClient({ region: REGION });
const cd  = new CodeDeployClient({ region: REGION });

exports.handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  const d = event && event.detail ? event.detail : {};
  if (event["detail-type"] !== "ECR Image Action" ||
      d["action-type"] !== "PUSH" ||
      d.result !== "SUCCESS") {
    console.log("Ignoring non-successful or non-push event");
    return { ignored: true };
  }

  const imageTag = d["image-tag"] || "latest";
  const repository = d["repository-name"];
  if (!repository) throw new Error("Missing repository-name from event");

  const family           = process.env.TASKDEF_FAMILY;      // e.g. "staging-urlshortener"
  const containerName    = process.env.CONTAINER_NAME;      // e.g. "staging-urlshortener"
  const containerPort    = parseInt(process.env.CONTAINER_PORT, 10);
  const taskRoleArn      = process.env.TASK_ROLE_ARN;
  const executionRoleArn = process.env.EXECUTION_ROLE_ARN;
  const applicationName  = process.env.APPLICATION_NAME;
  const deploymentGroup  = process.env.DEPLOYMENT_GROUP;
  const containerRepoUri = process.env.CONTAINER_REPO_URI;  // e.g. "0449....dkr.ecr.eu-west-2.amazonaws.com/staging-urlshortener"

  // 1) Describe current task def (by family) to clone settings
  const cur = await ecs.send(new DescribeTaskDefinitionCommand({ taskDefinition: family }));
  const td = cur.taskDefinition;

  // 2) Update image for target container
  const newContainerDefs = td.containerDefinitions.map((c) => {
    if (c.name === containerName) {
      return Object.assign({}, c, { image: containerRepoUri + ":" + imageTag });
    }
    return c;
  });

  // 3) Register new task definition revision
  const reg = await ecs.send(new RegisterTaskDefinitionCommand({
    family: family,
    networkMode: td.networkMode,
    requiresCompatibilities: td.requiresCompatibilities,
    cpu: td.cpu,
    memory: td.memory,
    executionRoleArn: executionRoleArn,
    taskRoleArn: taskRoleArn,
    volumes: td.volumes,
    placementConstraints: td.placementConstraints,
    proxyConfiguration: td.proxyConfiguration,
    ephemeralStorage: td.ephemeralStorage,
    containerDefinitions: newContainerDefs
  }));
  const taskDefArn = reg.taskDefinition.taskDefinitionArn;
  console.log("Registered task def:", taskDefArn);

  // 4) Trigger CodeDeploy deployment with inline AppSpec
  const appSpec = {
    version: 0.0,
    Resources: [{
      TargetService: {
        Type: "AWS::ECS::Service",
        Properties: {
          TaskDefinition: taskDefArn,
          LoadBalancerInfo: {
            ContainerName: containerName,
            ContainerPort: containerPort
          },
          PlatformVersion: "LATEST"
        }
      }
    }]
  };

  const res = await cd.send(new CreateDeploymentCommand({
    applicationName: applicationName,
    deploymentGroupName: deploymentGroup,
    revision: {
      revisionType: "AppSpecContent",
      appSpecContent: { content: JSON.stringify(appSpec) }
    },
    description: "ECR push " + repository + ":" + imageTag + " -> " + taskDefArn
  }));

  console.log("Deployment created:", res);
  return res;
};
